import streamlit as st

# 1. Page Configuration
st.set_page_config(page_title="AlgoHub AI", layout="wide")

# 2. CSS Styling
st.markdown("""
    <style>
        .stApp { background: linear-gradient(135deg, #0f0c29, #302b63, #24243e) !important; }
        .main-title { color: #ffffff !important; font-size: 5rem !important; text-align: center; font-weight: 900; text-transform: uppercase; }
        .sub-title { color: #ff007f !important; text-align: center; font-size: 1.5rem; margin-bottom: 40px; }
        div[data-testid="stTextInput"] > div > div > input { background: rgba(255, 255, 255, 0.15) !important; border: 2px solid #ff007f !important; color: white !important; border-radius: 12px; padding: 15px !important; }
    </style>
""", unsafe_allow_html=True)

# 3. Session State
if "logged_in" not in st.session_state:
    st.session_state.logged_in = False
if "messages" not in st.session_state:
    st.session_state.messages = []

# 4. Login Logic
if not st.session_state.logged_in:
    st.markdown("<h1 class='main-title'>ALGOHUB</h1>", unsafe_allow_html=True)
    st.markdown("<p class='sub-title'>AI ASSISTANT DEVELOPMENT</p>", unsafe_allow_html=True)
    
    col1, col2, col3 = st.columns([1.5, 3, 1.5])
    with col2:
        api_key = st.text_input("ENTER YOUR OPENAI API KEY", type="password")
        if st.button("INITIALIZE SESSION"):
            if api_key:
                st.session_state.logged_in = True
                st.rerun()
            else:
                st.error("Please enter a valid API Key.")

# 5. Chat Interface (With Dummy Response)
else:
    st.title("🤖 AlgoHub AI Assistant")
    
    if st.sidebar.button("Logout"):
        st.session_state.logged_in = False
        st.session_state.messages = []
        st.rerun()

    for message in st.session_state.messages:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])

    if prompt := st.chat_input("Ask me anything..."):
        st.session_state.messages.append({"role": "user", "content": prompt})
        with st.chat_message("user"):
            st.markdown(prompt)

        with st.chat_message("assistant"):
            # Dummy/Mock Response for Demo
            mock_response = f"AlgoHub AI acknowledges your request: '{prompt}'. Currently, I am in Demo mode, but I can process your logic perfectly!"
            st.markdown(mock_response)
            st.session_state.messages.append({"role": "assistant", "content": mock_response})